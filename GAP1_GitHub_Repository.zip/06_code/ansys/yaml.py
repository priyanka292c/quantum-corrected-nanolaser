"""PyYAML compatibility layer using ruamel.yaml"""
import ruamel.yaml

_yaml = ruamel.yaml.YAML(typ="safe", pure=True)

def safe_load(stream):
    return _yaml.load(stream)

def load(stream, Loader=None):
    return _yaml.load(stream)

def dump(data, stream=None, **kwargs):
    if stream is None:
        import io
        s = io.StringIO()
        _yaml.dump(data, s)
        return s.getvalue()
    return _yaml.dump(data, stream)

def safe_dump(data, stream=None, **kwargs):
    return dump(data, stream, **kwargs)
