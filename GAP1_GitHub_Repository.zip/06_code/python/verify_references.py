"""
Reference DOI Verification Script (both GAP1 and GAP2)
=======================================================
Reads reference_audit.csv and attempts to resolve every DOI against doi.org.
Prints a pass/fail summary. Should be run before every submission.

Usage:
    python verify_references.py --audit path/to/reference_audit.csv

Requirements:
    pip install requests
"""

import argparse
import csv
import logging
import time
from pathlib import Path

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s  %(levelname)-8s  %(message)s")
log = logging.getLogger("ref_verify")

DOI_RESOLVE_URL = "https://doi.org/"
HEADERS = {"Accept": "application/json"}
RATE_LIMIT_S = 0.5   # be polite to doi.org


def verify_doi(doi: str, key: str) -> dict:
    """
    Attempt to resolve a DOI via doi.org API.
    Returns dict with status, resolved_url, and any error.
    """
    if not doi or doi.strip().startswith("["):
        return {"key": key, "doi": doi, "status": "SKIPPED_NO_DOI",
                "resolved_url": "", "error": ""}
    url = DOI_RESOLVE_URL + doi.strip()
    try:
        r = requests.get(url, headers=HEADERS, allow_redirects=False, timeout=10)
        if r.status_code in (200, 301, 302, 303, 307):
            target = r.headers.get("Location", r.url)
            return {"key": key, "doi": doi, "status": "VERIFIED_OK",
                    "resolved_url": target, "error": ""}
        else:
            return {"key": key, "doi": doi,
                    "status": f"HTTP_{r.status_code}",
                    "resolved_url": r.url, "error": f"HTTP {r.status_code}"}
    except Exception as e:
        return {"key": key, "doi": doi, "status": "ERROR",
                "resolved_url": "", "error": str(e)}


def run_verification(audit_path: Path) -> list:
    results = []
    with open(audit_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows   = list(reader)

    log.info(f"Verifying {len(rows)} references from {audit_path}...")
    for row in rows:
        key    = row.get("key", "")
        doi    = row.get("doi", "")
        vstatus = row.get("verification_status", "")

        # Skip anchor entries that already have manual status
        if vstatus in {"ACCEPTED_ANCHOR", "ACCEPTED_NODOI"}:
            log.info(f"  [{key}] Skipped (status={vstatus})")
            results.append({"key": key, "doi": doi, "status": vstatus,
                            "resolved_url": "", "error": ""})
            continue

        if not REQUESTS_AVAILABLE:
            log.warning("  requests not installed — dry run.")
            results.append({"key": key, "doi": doi, "status": "DRY_RUN",
                            "resolved_url": "", "error": "requests not available"})
            continue

        res = verify_doi(doi, key)
        emoji = "✓" if res["status"] == "VERIFIED_OK" else "✗"
        log.info(f"  {emoji} [{key}] DOI={doi} → {res['status']}")
        results.append(res)
        time.sleep(RATE_LIMIT_S)

    return results


def save_results(results: list, audit_path: Path):
    out_path = audit_path.parent / (audit_path.stem + "_verified.csv")
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f,
            fieldnames=["key", "doi", "status", "resolved_url", "error"])
        w.writeheader()
        w.writerows(results)
    log.info(f"Verification report: {out_path}")
    return out_path


def print_summary(results: list):
    counts = {}
    for r in results:
        counts[r["status"]] = counts.get(r["status"], 0) + 1
    log.info("=== Summary ===")
    for s, n in sorted(counts.items()):
        log.info(f"  {s:30s}: {n}")
    failed = [r for r in results if r["status"] not in
              {"VERIFIED_OK", "SKIPPED_NO_DOI", "ACCEPTED_ANCHOR",
               "ACCEPTED_NODOI", "DRY_RUN"}]
    if failed:
        log.warning(f"  {len(failed)} reference(s) failed verification:")
        for r in failed:
            log.warning(f"    [{r['key']}] {r['doi']} — {r['status']}: {r['error']}")
    else:
        log.info("  All verifiable DOIs resolved successfully.")


def main():
    parser = argparse.ArgumentParser(description="DOI verification for reference audit CSV")
    parser.add_argument("--audit", type=Path,
                        default=Path(__file__).parent.parent.parent /
                                "GAP1_Plasmonics" / "01_main_manuscript" / "reference_audit.csv",
                        help="Path to reference_audit.csv")
    args = parser.parse_args()

    if not args.audit.exists():
        log.error(f"Audit file not found: {args.audit}")
        return

    results = run_verification(args.audit)
    save_results(results, args.audit)
    print_summary(results)


if __name__ == "__main__":
    main()
