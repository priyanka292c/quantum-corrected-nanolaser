# Quantum-Corrected Nonlocal Electromagnetic Design of Hybrid Plasmonic--Photonic Crystal Quantum-Dot Nanolasers

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Python: 3.9+](https://img.shields.io/badge/Python-3.9+-brightgreen.svg)](https://www.python.org/)
[![Status: Submitted](https://img.shields.io/badge/Status-Under%20Review-orange.svg)](https://www.springer.com/journal/11468)

This repository contains the simulation code, processed datasets, analytical scripts, and LaTeX manuscript sources for the study:

> **Quantum-Corrected Nonlocal Electromagnetic Design of Hybrid Plasmonic--Photonic Crystal Quantum-Dot Nanolasers**  
> **Authors:** Priyanka (1,*) and Ram Soorat (2)  
> *(1) Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India*  
> *(2) School of Technology, Woxsen University, Hyderabad 502345, Telangana, India*  
> *\* Corresponding Author:* `priyanka292c@gmail.com`  
> **Target Journal:** *Plasmonics* (Springer Nature)  
> **Run Identifier:** `GAP1-2026-001`

---

## 📌 Executive Summary & Key Highlights

This work addresses a foundational open question in computational nanophotonics: **at what emitter–metal separation does the classical or continuum nonlocal description of a plasmonic nanolaser cease to be physically adequate, and what is the actionable physical design window?**

We present a systematic, cross-validated numerical investigation comparing three electromagnetic models across a continuous 0.2 nm to 50 nm gap sweep:
1. **Local Response Approximation (LRA):** Standard local Drude–Lorentz electrodynamics.
2. **Generalized Nonlocal Optical Response (GNOR):** Hydrodynamic model incorporating convection and electron diffusion ($\beta_\text{NL} = 1.27 \times 10^6\text{ m/s}$, $D = 8.8 \times 10^{-4}\text{ m}^2/\text{s}$).
3. **Quantum-Corrected Surface-Response (QCSR):** Phenomenological quantum surface model incorporating electron spill-out, quantum tunneling, and interfacial Landau damping.

### Key Findings:
- **Peak Purcell Factor Quenching:** The QCSR model demonstrates a non-monotonic Purcell factor peaking near $d \approx 0.8\text{ nm}$ ($F_P \approx 420$), in stark contrast to unphysical monotonic divergence in classical LRA ($F_P > 10^4$).
- **Actionable Design Window:** Identification of a robust nanolaser operating window at **$d = 2\text{--}4\text{ nm}$**, maximizing the Purcell factor and mode confinement while suppressing non-radiative quenching losses.
- **Sobol Variance-Based Sensitivity:** QCSR surface conductivity parameters govern $>75\%$ of model variance below 1 nm, while hydrodynamic GNOR parameters dominate in the 1–5 nm transition regime.

---

## 📂 Repository Structure

```plaintext
.
├── 01_main_manuscript/        # LaTeX source (main.tex), bibliography, and compiled PDF
├── 02_cover_letter/           # Formal journal cover letter to Plasmonics (Springer)
├── 03_supplementary/          # Supplementary Information LaTeX source & compiled PDF
├── 04_figures/                # Vector publication figures (PDF format, Fig 3 to Fig 12)
├── 04_graphical_abstract/     # Graphical abstract source (TikZ), high-res PNG & PDF
├── 05_beamer/                 # Conference presentation slides (LaTeX Beamer & PDF)
├── 06_code/                   # Simulation, analysis, and visualization source code
│   ├── ansys/                 # 3D FDTD gap sweep automation scripts (Lumerical)
│   ├── configs/               # Master YAML parameter definitions (parameters.yaml)
│   ├── matlab_bem/            # MNPBEM boundary element cross-validation solver scripts
│   └── python/                # Figure generation and Sobol sensitivity scripts
├── 07_data/                   # Raw and processed datasets
│   ├── manifests/             # Data-to-figure provenance mapping (manifest.json)
│   ├── processed/             # CSV outputs (Purcell factors, Sobol indices, MNPBEM results)
│   └── raw/                   # Raw simulation logs and metadata
├── 08_validation/             # Grid convergence, boundary PML, and cross-solver validation
└── 09_submission/             # Consolidated, production-ready submission package
```

---

## 🚀 Reproduction & Usage Instructions

### 1. Generating Figures
All manuscript figures (Fig. 3 through Fig. 12) can be reproduced directly using Python:
```bash
python -m pip install numpy scipy matplotlib pyyaml
python 06_code/python/generate_gap1_figures.py
```
Output figures will be saved in `04_figures/` as publication-ready vector PDFs.

### 2. Running Sobol Uncertainty Quantification
To run the variance-based Sobol global sensitivity analysis:
```bash
python 06_code/python/gap1_sobol_uq.py
```

### 3. Compiling Manuscript & Supplementary Documents
To build the main manuscript and supplementary documents using `pdflatex` and `bibtex`:
```bash
# Main Manuscript
cd 01_main_manuscript
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex

# Supplementary Information
cd ../03_supplementary
pdflatex supplementary.tex
bibtex supplementary
pdflatex supplementary.tex
pdflatex supplementary.tex
```

---

## 📜 Citation & License

If you use this code, data, or methodology in your research, please cite:

```bibtex
@article{priyanka2026quantum,
  title={Quantum-Corrected Nonlocal Electromagnetic Design of Hybrid Plasmonic--Photonic Crystal Quantum-Dot Nanolasers},
  author={Priyanka and Soorat, Ram},
  journal={Plasmonics},
  year={2026},
  note={Under review; Run ID: GAP1-2026-001}
}
```

This project is licensed under the MIT License - see the LICENSE file for details.
