# GAP1 Raw Simulation Data Directory

This directory contains raw simulation logs, field profiles, and modal parameters for the quantum-corrected nonlocal nanolaser study.

- **Run ID**: `GAP1-2026-001`
- **Configuration**: `06_code/configs/parameters.yaml`
- **Automation Scripts**:
  - `06_code/ansys/gap1_fdtd_sweep.py` (Lumerical 3D-FDTD gap sweep automation)
  - `06_code/matlab_bem/gap1_mnpbem_sweep.m` (MNPBEM boundary element cross-validation)
- **Processed Outputs**:
  - `07_data/processed/purcell_vs_gap_GAP1-2026-001.csv`
  - `07_data/processed/mnpbem_results_GAP1-2026-001.csv`
  - `07_data/processed/sobol_indices_GAP1-2026-001.csv`
- **Manifest**: `07_data/manifests/manifest.json` maps all manuscript figures and tables to these data files.
