# Raw Output Archive for Run GAP1-2026-001

Contains the primary 3D-FDTD parameter sweep files across emitter-metal gaps ($d = 0.2$ to $50$ nm) for LRA, GNOR, and QCSR models.
Refer to `07_data/manifests/manifest.json` for figure/table linkage.
